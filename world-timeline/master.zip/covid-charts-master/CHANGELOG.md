# covid-charts Changelog

This is a changelog of amCharts COVID-19 coverage templates/data project.

Updates are not versioned. This log includes only noteworthy updates.

## 2020-04-03
- Added experimental current and timeline data for U.S. states.
- Added beta version of U.S. dashboard example (`examples/usa`).

## 2020-03-28
- Dashboard now allows switching between daily and cummulative data.

## 2020-03-24
- No longer generating individual country data files.

## 2020-03-23
- No longer generating individual daily files.

## 2020-03-22
- Data is now updated several times a day and is generally more up-to-date.